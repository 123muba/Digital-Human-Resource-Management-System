<?php
// save_records.php

header('Content-Type: application/json');

// Database connection
$host = "localhost";
$user = "root";
$password = "";
$db = "hr_system";

$conn = new mysqli($host, $user, $password, $db);
if ($conn->connect_error) {
    echo json_encode(["success" => false, "message" => "Connection failed"]);
    exit;
}

$type = $_POST['type'] ?? '';
$employee = $_POST['employee'] ?? '';
$status = $_POST['status'] ?? '';
$date = $_POST['date'] ?? '';
$allowance = $_POST['allowance'] ?? null;

if ($type === "notification") {
    $stmt = $conn->prepare("INSERT INTO notifications (employee, status, date) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $employee, $status, $date);
} elseif ($type === "attendance") {
    $stmt = $conn->prepare("INSERT INTO attendance (employee, status, allowance, date) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssis", $employee, $status, $allowance, $date);
} else {
    echo json_encode(["success" => false, "message" => "Invalid type"]);
    exit;
}

if ($stmt->execute()) {
    echo json_encode(["success" => true]);
} else {
    echo json_encode(["success" => false, "message" => $stmt->error]);
}

$stmt->close();
$conn->close();
