<?php
header('Content-Type: application/json');

// 1) Database connection
$host = 'localhost';
$user = 'root';        // ← change if needed
$pass = '';            // ← change if needed
$db   = 'hr_system';

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    http_response_code(500);
    exit(json_encode([
        'success' => false,
        'message' => 'DB connection failed'
    ]));
}

// 2) Parse JSON body
$body = json_decode(file_get_contents('php://input'), true);
if (!is_array($body)) {
    http_response_code(400);
    exit(json_encode(['success'=>false,'message'=>'Invalid JSON']));
}

// 3) Validate required fields
foreach (['employee_name','allowance_type','amount','date_given'] as $f) {
    if (empty($body[$f])) {
        http_response_code(400);
        exit(json_encode([
            'success' => false,
            'message' => "Missing field: $f"
        ]));
    }
}

// 4) Prepare & execute INSERT
$stmt = $conn->prepare(
    "INSERT INTO allowances
      (employee_name, allowance_type, amount, date_given)
     VALUES (?,?,?,?)"
);
$stmt->bind_param(
    "ssds",
    $body['employee_name'],
    $body['allowance_type'],
    $body['amount'],
    $body['date_given']
);

if ($stmt->execute()) {
    echo json_encode([
        'success' => true,
        'id'      => $stmt->insert_id
    ]);
} else {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => $stmt->error
    ]);
}

$stmt->close();
$conn->close();
?>
