<?php
// Enable CORS if testing locally
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

// DB config
$host = "localhost";
$user = "root";
$password = ""; // Change if needed
$dbname = "your_database_name"; // 🔁 Replace with your actual database name

$conn = new mysqli($host, $user, $password, $dbname);
if ($conn->connect_error) {
    echo json_encode(["success" => false, "message" => "Connection failed: " . $conn->connect_error]);
    exit();
}

// Get data from fetch POST
$data = json_decode(file_get_contents("php://input"), true);

if (
    isset($data['employee_name']) &&
    isset($data['leave_type']) &&
    isset($data['start_date']) &&
    isset($data['end_date']) &&
    isset($data['reason']) &&
    isset($data['status'])
) {
    $stmt = $conn->prepare("INSERT INTO leave_requests (employee_name, leave_type, start_date, end_date, reason, status)
                            VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssss", $data['employee_name'], $data['leave_type'], $data['start_date'], $data['end_date'], $data['reason'], $data['status']);

    if ($stmt->execute()) {
        echo json_encode(["success" => true, "message" => "Leave saved to database."]);
    } else {
        echo json_encode(["success" => false, "message" => "DB Insert failed: " . $stmt->error]);
    }

    $stmt->close();
} else {
    echo json_encode(["success" => false, "message" => "Invalid input."]);
}

$conn->close();
?>
