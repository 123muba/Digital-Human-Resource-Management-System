<?php
// save_data.php

// Database connection
$host = "localhost";
$user = "root";
$pass = "";
$dbname = "hr_system";

$conn = new mysqli($host, $user, $pass, $dbname);
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Get POST data
$data = json_decode(file_get_contents("php://input"), true);

// Determine what type of data we received
$type = $data['type'];

if ($type === 'job') {
  $category = $conn->real_escape_string($data['category']);
  $title = $conn->real_escape_string($data['title']);
  $description = $conn->real_escape_string($data['description']);

  $sql = "INSERT INTO jobs (category, title, description) VALUES ('$category', '$title', '$description')";

  if ($conn->query($sql)) {
    echo json_encode(["status" => "success"]);
  } else {
    echo json_encode(["status" => "error", "message" => $conn->error]);
  }

} else if ($type === 'task') {
  $title = $conn->real_escape_string($data['title']);
  $description = $conn->real_escape_string($data['description']);

  $sql = "INSERT INTO onboarding_tasks (title, description) VALUES ('$title', '$description')";

  if ($conn->query($sql)) {
    echo json_encode(["status" => "success"]);
  } else {
    echo json_encode(["status" => "error", "message" => $conn->error]);
  }
} else {
  echo json_encode(["status" => "error", "message" => "Unknown data type."]);
}

$conn->close();
?>
