<?php
// Database connection (adjust the credentials accordingly)
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "your_database_name"; // Change this to your actual database name

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get the JSON input from the request body
$inputData = file_get_contents("php://input");
$data = json_decode($inputData, true);

// Check if data is valid
if (isset($data['name'], $data['email'], $data['message'])) {
    $name = $conn->real_escape_string($data['name']);
    $email = $conn->real_escape_string($data['email']);
    $subject = $conn->real_escape_string($data['subject']);
    $message = $conn->real_escape_string($data['message']);

    // Insert the data into the database
    $sql = "INSERT INTO messages (name, email, subject, message) VALUES ('$name', '$email', '$subject', '$message')";

    if ($conn->query($sql) === TRUE) {
        // Send a JSON response back to the client
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Error: ' . $conn->error]);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid data']);
}

// Close connection
$conn->close();
?>
