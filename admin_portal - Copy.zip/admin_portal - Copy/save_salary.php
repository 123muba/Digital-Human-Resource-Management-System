<?php
// Database connection (update with your credentials)
$servername = "localhost";
$username = "root";  // Replace with your database username
$password = "";      // Replace with your database password
$dbname = "hr_system"; // Replace with your database name

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $employee_name = $_POST['employee_name'];
  $base_salary = $_POST['base_salary'];
  $allowance = $_POST['allowance'];
  $days_present = $_POST['days_present'];
  $calculated_salary = $_POST['calculated_salary'];
  $status = $_POST['status'];
  $date = $_POST['date'];

  // Prepare SQL query
  $sql = "INSERT INTO salaries (employee_name, base_salary, allowance, days_present, calculated_salary, status, date) 
          VALUES (?, ?, ?, ?, ?, ?, ?)";

  $stmt = $conn->prepare($sql);
  $stmt->bind_param("sdddsds", $employee_name, $base_salary, $allowance, $days_present, $calculated_salary, $status, $date);

  if ($stmt->execute()) {
    echo json_encode(["success" => true]);
  } else {
    echo json_encode(["success" => false, "message" => "Error inserting data"]);
  }

  $stmt->close();
  $conn->close();
}
?>
