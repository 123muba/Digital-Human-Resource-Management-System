<?php
// performance_api.php
header('Content-Type: application/json');

// 1. Database connection
$host = 'localhost';
$user = 'root';        // change if needed
$pass = '';            // change if needed
$db   = 'hr_system';

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    http_response_code(500);
    exit(json_encode(['success'=>false,'message'=>'DB connect error']));
}

// 2. Pull in JSON
$input = json_decode(file_get_contents('php://input'), true);
$type  = $input['type'] ?? '';

// 3. Route by type
if ($type === 'employee') {
    // insert new employee
    $name = $conn->real_escape_string($input['name']);
    $sql  = "INSERT INTO employees (name) VALUES ('$name')";
    if ($conn->query($sql)) {
        echo json_encode(['success'=>true,'id'=>$conn->insert_id]);
    } else {
        echo json_encode(['success'=>false,'message'=>$conn->error]);
    }

} elseif ($type === 'goal') {
    // insert new performance goal
    $emp   = $conn->real_escape_string($input['employee']);
    $goal  = $conn->real_escape_string($input['goal']);
    $cycle = $conn->real_escape_string($input['reviewCycle']);
    $stat  = $conn->real_escape_string($input['status']);

    $sql = "INSERT INTO performance_goals
              (employee_name, goal_text, review_cycle, status)
            VALUES
              ('$emp', '$goal', '$cycle', '$stat')";

    if ($conn->query($sql)) {
        echo json_encode(['success'=>true,'id'=>$conn->insert_id]);
    } else {
        echo json_encode(['success'=>false,'message'=>$conn->error]);
    }

} else {
    http_response_code(400);
    echo json_encode(['success'=>false,'message'=>'Invalid type']);
}

$conn->close();
?>
