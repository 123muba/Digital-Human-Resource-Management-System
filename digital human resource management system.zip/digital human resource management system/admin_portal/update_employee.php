<?php
include 'db.php';

$data = json_decode(file_get_contents("php://input"), true);

$stmt = $conn->prepare("UPDATE employees SET full_name=?, email=?, phone=?, department=?, job_title=?, hire_date=?, role=?, work_status=? WHERE id=?");
$stmt->bind_param("ssssssssi", 
    $data['full_name'],
    $data['email'],
    $data['phone'],
    $data['department'],
    $data['job_title'],
    $data['hire_date'],
    $data['role'],
    $data['work_status'],
    $data['id']
);

if ($stmt->execute()) {
    echo json_encode(["status" => "success"]);
} else {
    echo json_encode(["status" => "error", "message" => $conn->error]);
}
?>
