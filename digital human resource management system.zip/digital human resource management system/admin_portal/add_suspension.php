<?php
header('Content-Type: application/json');

// 1) Database connection (adjust creds as needed)
$host = 'localhost';
$user = 'root';
$pass = '';
$db   = 'hr_system';

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    http_response_code(500);
    exit(json_encode(['success' => false, 'message' => 'DB connection failed']));
}

// 2) Retrieve and validate POST data
$employee_name = $_POST['employee_name'] ?? '';
$reason        = $_POST['reason']        ?? '';
$start_date    = $_POST['start_date']    ?? '';
$end_date      = $_POST['end_date']      ?? '';

if (!$employee_name || !$reason || !$start_date || !$end_date) {
    http_response_code(400);
    exit(json_encode(['success' => false, 'message' => 'Missing required fields']));
}

// 3) Insert into database
$stmt = $conn->prepare(
    "INSERT INTO suspensions 
       (employee_name, reason, start_date, end_date) 
     VALUES (?, ?, ?, ?)"
);
$stmt->bind_param('ssss', $employee_name, $reason, $start_date, $end_date);

if ($stmt->execute()) {
    echo json_encode(['success' => true]);
} else {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => $stmt->error]);
}

$stmt->close();
$conn->close();
?>
