CREATE DATABASE IF NOT EXISTS hr_system;

USE hr_system;

-- Employees Table
CREATE TABLE IF NOT EXISTS employees (
    id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(100),
    email VARCHAR(100),
    phone VARCHAR(20),
    department VARCHAR(100),
    job_title VARCHAR(100),
    hire_date DATE,
    role VARCHAR(20),
    work_status VARCHAR(20)
);

-- Notifications Table
CREATE TABLE notifications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    employee VARCHAR(100),
    status VARCHAR(50),
    date DATE
);

-- Attendance Table
CREATE TABLE attendance (
    id INT AUTO_INCREMENT PRIMARY KEY,
    employee VARCHAR(100),
    status VARCHAR(50),
    allowance INT,
    date DATE
);

-- Leave Requests Table
CREATE TABLE leave_requests (
    id INT AUTO_INCREMENT PRIMARY KEY,
    employee_name VARCHAR(255) NOT NULL,
    leave_type VARCHAR(50) NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    reason TEXT NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'Pending',
    date_submitted DATE NOT NULL DEFAULT (CURRENT_DATE())
);

-- Jobs Table
CREATE TABLE jobs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(100) NOT NULL,
    description TEXT NOT NULL
);

-- Onboarding Tasks Table
CREATE TABLE onboarding_tasks (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(100) NOT NULL,
    description TEXT NOT NULL
);

-- Applicants Table
CREATE TABLE applicants (
    id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    job_title VARCHAR(100) NOT NULL,
    status VARCHAR(50) DEFAULT 'Pending'
);

-- Extended Users Table
CREATE TABLE users_extended (
    id INT AUTO_INCREMENT PRIMARY KEY,
    role VARCHAR(20),
    name VARCHAR(100),
    sex VARCHAR(10),
    dob DATE,
    age INT,
    birthplace VARCHAR(100),
    civil_status VARCHAR(20),
    citizenship VARCHAR(50),
    password VARCHAR(255),

    spouse_surname VARCHAR(100),
    spouse_firstname VARCHAR(100),
    spouse_middlename VARCHAR(100),
    spouse_occupation VARCHAR(100),
    employer VARCHAR(100),
    business_address VARCHAR(200),
    bus_tel VARCHAR(50),
    spouse_contact VARCHAR(50),

    educ_level VARCHAR(20),
    school VARCHAR(100),
    degree VARCHAR(50),
    year_grad VARCHAR(10),

    work_exp TEXT,
    training TEXT,
    file_upload VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Employees (Simple) Table for Goals/Reference
CREATE TABLE IF NOT EXISTS employees (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Performance Goals Table
CREATE TABLE IF NOT EXISTS performance_goals (
    id INT AUTO_INCREMENT PRIMARY KEY,
    employee_name VARCHAR(100) NOT NULL,
    goal_text TEXT NOT NULL,
    review_cycle VARCHAR(50) NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'Pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Allowances Table
CREATE TABLE IF NOT EXISTS allowances (
    id INT AUTO_INCREMENT PRIMARY KEY,
    employee_name VARCHAR(100) NOT NULL,
    allowance_type VARCHAR(100) NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    date_given DATE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Promotions & Demotions Table
CREATE TABLE promotions_demotions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    employee_name VARCHAR(255) NOT NULL,
    type ENUM('Promotion', 'Demotion') NOT NULL,
    performance_score INT NOT NULL,
    new_position VARCHAR(255) NOT NULL,
    reason TEXT NOT NULL,
    documentation VARCHAR(255),
    date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Salaries Table
CREATE TABLE salaries (
    id INT AUTO_INCREMENT PRIMARY KEY,
    employee_name VARCHAR(255) NOT NULL,
    base_salary DECIMAL(10, 2) NOT NULL,
    allowance DECIMAL(10, 2) NOT NULL,
    days_present INT NOT NULL,
    calculated_salary DECIMAL(10, 2) NOT NULL,
    status VARCHAR(50) DEFAULT 'Pending',
    date DATE NOT NULL
);

-- Suspensions Table
CREATE TABLE IF NOT EXISTS suspensions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    employee_name VARCHAR(255) NOT NULL,
    reason TEXT NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Messages Table
CREATE TABLE messages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    subject VARCHAR(255),
    message TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ✅ Secure Employee Admin Table
CREATE TABLE employee_admin (
    id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL,
    password VARCHAR(255) NOT NULL,
    role ENUM('admin', 'employee') NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
