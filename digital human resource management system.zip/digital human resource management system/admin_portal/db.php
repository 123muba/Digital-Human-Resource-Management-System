<?php
$host = "localhost";
$user = "root";      // Change if not using default
$pass = "";          // Change if you have a password
$db   = "hr_system";

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
