<?php
$host = 'localhost';
$db = 'hr_system';
$user = 'root';
$pass = '';
$dsn = "mysql:host=$host;dbname=$db;charset=utf8mb4";

try {
  $pdo = new PDO($dsn, $user, $pass);
} catch (PDOException $e) {
  http_response_code(500);
  echo json_encode(['error' => 'Database connection failed']);
  exit;
}

$action = $_GET['action'] ?? '';

header('Content-Type: application/json');

switch ($action) {
  case 'get_jobs':
    $stmt = $pdo->query("SELECT * FROM jobs ORDER BY id DESC");
    echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
    break;

  case 'get_tasks':
    $stmt = $pdo->query("SELECT * FROM onboarding_tasks ORDER BY id DESC");
    echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
    break;

  case 'get_applicants':
    $stmt = $pdo->query("SELECT * FROM applicants ORDER BY id DESC");
    echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
    break;

  case 'add_applicant':
    $data = json_decode(file_get_contents("php://input"), true);
    $stmt = $pdo->prepare("INSERT INTO applicants (full_name, email, job_title) VALUES (?, ?, ?)");
    $stmt->execute([$data['full_name'], $data['email'], $data['job_title']]);
    echo json_encode(['success' => true]);
    break;

  case 'add_job':
    $data = json_decode(file_get_contents("php://input"), true);
    $stmt = $pdo->prepare("INSERT INTO jobs (title, description) VALUES (?, ?)");
    $stmt->execute([$data['title'], $data['description']]);
    echo json_encode(['success' => true]);
    break;

  case 'add_task':
    $data = json_decode(file_get_contents("php://input"), true);
    $stmt = $pdo->prepare("INSERT INTO onboarding_tasks (title, description) VALUES (?, ?)");
    $stmt->execute([$data['title'], $data['description']]);
    echo json_encode(['success' => true]);
    break;

  default:
    http_response_code(400);
    echo json_encode(['error' => 'Invalid action']);
}
?>
