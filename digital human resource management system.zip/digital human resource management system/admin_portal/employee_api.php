<?php
// employee_api.php

header('Content-Type: application/json');

// 1) Include database connection
include 'db.php';  // assumes db.php sets up $conn = new mysqli(...);

// 2) Determine request method and action
$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? ($_POST['action'] ?? null);

// 3) Utility: get JSON body (for POST)
function get_json_body() {
    $data = json_decode(file_get_contents('php://input'), true);
    return is_array($data) ? $data : $_POST;
}

// 4) Route requests
if ($method === 'GET') {
    // ── FETCH ALL ──
    if ($action === 'fetch' || !$action) {
        $result = $conn->query("SELECT * FROM employees ORDER BY id DESC");
        $rows = $result->fetch_all(MYSQLI_ASSOC);
        echo json_encode($rows);
        exit;
    }

    // ── FETCH SINGLE ──
    if ($action === 'fetch_single' && isset($_GET['id'])) {
        $id = intval($_GET['id']);
        $res = $conn->query("SELECT * FROM employees WHERE id = $id");
        echo json_encode($res->fetch_assoc());
        exit;
    }

    // invalid GET action
    echo json_encode(['status'=>'error','message'=>'Invalid GET action']);
    exit;
}

if ($method === 'POST') {
    $data = get_json_body();

    // ── ADD ──
    if ($action === 'add') {
        $stmt = $conn->prepare(
            "INSERT INTO employees
               (full_name,email,phone,department,job_title,hire_date,role,work_status)
             VALUES (?,?,?,?,?,?,?,?)"
        );
        $stmt->bind_param(
            "ssssssss",
            $data['full_name'],
            $data['email'],
            $data['phone'],
            $data['department'],
            $data['job_title'],
            $data['hire_date'],
            $data['role'],
            $data['work_status']
        );
        if ($stmt->execute()) {
            echo json_encode(['status'=>'success','id'=>$stmt->insert_id]);
        } else {
            echo json_encode(['status'=>'error','message'=>$conn->error]);
        }
        exit;
    }

    // ── UPDATE ──
    if ($action === 'update' && isset($data['id'])) {
        $stmt = $conn->prepare(
            "UPDATE employees SET
              full_name=?, email=?, phone=?, department=?, job_title=?, hire_date=?, role=?, work_status=?
             WHERE id=?"
        );
        $stmt->bind_param(
            "ssssssssi",
            $data['full_name'],
            $data['email'],
            $data['phone'],
            $data['department'],
            $data['job_title'],
            $data['hire_date'],
            $data['role'],
            $data['work_status'],
            $data['id']
        );
        if ($stmt->execute()) {
            echo json_encode(['status'=>'success']);
        } else {
            echo json_encode(['status'=>'error','message'=>$conn->error]);
        }
        exit;
    }

    // ── DELETE ──
    if ($action === 'delete' && isset($data['id'])) {
        $stmt = $conn->prepare("DELETE FROM employees WHERE id = ?");
        $stmt->bind_param("i", $data['id']);
        if ($stmt->execute()) {
            echo json_encode(['status'=>'success']);
        } else {
            echo json_encode(['status'=>'error','message'=>$conn->error]);
        }
        exit;
    }

    // invalid POST action
    echo json_encode(['status'=>'error','message'=>'Invalid POST action or missing parameters']);
    exit;
}

// unsupported method
echo json_encode(['status'=>'error','message'=>'Unsupported HTTP method']);
exit;
?>
