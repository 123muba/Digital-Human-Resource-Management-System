<?php
// 2) PHP: save as leave_api.php

header('Content-Type: application/json');

// — Database connection (adjust creds) —
$host = 'localhost';
$user = 'root';
$pass = '';
$db   = 'hr_system';

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    http_response_code(500);
    exit(json_encode(['success'=>false,'message'=>'DB connect failed']));
}

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    // ── Fetch all leave requests ──
    $res = $conn->query("SELECT * FROM leave_requests ORDER BY submitted_at DESC");
    $rows = $res->fetch_all(MYSQLI_ASSOC);
    echo json_encode($rows);
    exit;
}

if ($method === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    // ── Update status ──
    if (isset($data['id'], $data['status'])) {
        $stmt = $conn->prepare(
            "UPDATE leave_requests 
               SET status = ? 
             WHERE id = ?"
        );
        $stmt->bind_param('si', $data['status'], $data['id']);
        $ok = $stmt->execute();
        echo json_encode(['success'=>$ok]);
        exit;
    }

    // ── (Optional) Add a new leave request ──
    if (
      isset(
        $data['employee_name'],
        $data['leave_type'],
        $data['start_date'],
        $data['end_date'],
        $data['reason']
      )
    ) {
      $stmt = $conn->prepare(
        "INSERT INTO leave_requests
          (employee_name, leave_type, start_date, end_date, reason, status)
         VALUES (?,?,?,?,?,'Pending')"
      );
      $stmt->bind_param(
        'sssss',
        $data['employee_name'],
        $data['leave_type'],
        $data['start_date'],
        $data['end_date'],
        $data['reason']
      );
      $ok = $stmt->execute();
      echo json_encode(['success'=>$ok,'id'=>$stmt->insert_id]);
      exit;
    }

    http_response_code(400);
    echo json_encode(['success'=>false,'message'=>'Invalid POST data']);
    exit;
}

// Unsupported method
http_response_code(405);
echo json_encode(['success'=>false,'message'=>'Method not allowed']);
