<?php
$host = "localhost";
$user = "root";
$password = "";  // or your DB password
$database = "hr_system"; // make sure this database exists

$conn = new mysqli($host, $user, $password, $database);
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$data = json_decode(file_get_contents("php://input"), true);

$full_name = $conn->real_escape_string($data["full_name"]);
$email = $conn->real_escape_string($data["email"]);
$phone = $conn->real_escape_string($data["phone"]);
$department = $conn->real_escape_string($data["department"]);
$job_title = $conn->real_escape_string($data["job_title"]);
$hire_date = $conn->real_escape_string($data["hire_date"]);
$role = $conn->real_escape_string($data["role"]);
$work_status = $conn->real_escape_string($data["work_status"]);

$sql = "INSERT INTO employees (full_name, email, phone, department, job_title, hire_date, role, work_status)
        VALUES ('$full_name', '$email', '$phone', '$department', '$job_title', '$hire_date', '$role', '$work_status')";

if ($conn->query($sql) === TRUE) {
  echo json_encode(["success" => true]);
} else {
  echo json_encode(["success" => false, "error" => $conn->error]);
}

$conn->close();
?>
