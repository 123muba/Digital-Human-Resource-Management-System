<?php
// Database connection
$servername = "localhost";  // your DB server
$username = "root";         // your DB username
$password = "";             // your DB password
$dbname = "hr_system";      // your DB name

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get POST data
$employee_name = $_POST['employee_name'];
$type = $_POST['type'];
$performance_score = $_POST['performance_score'];
$new_position = $_POST['new_position'];
$reason = $_POST['reason'];

// Handle file upload
if ($_FILES['documentation']['name']) {
    $file_name = $_FILES['documentation']['name'];
    $file_tmp = $_FILES['documentation']['tmp_name'];
    $file_path = 'uploads/' . $file_name;
    
    // Move the file to the desired directory
    move_uploaded_file($file_tmp, $file_path);
} else {
    $file_path = null;
}

// Insert into database
$sql = "INSERT INTO promotions_demotions (employee_name, type, performance_score, new_position, reason, documentation, date) 
        VALUES ('$employee_name', '$type', '$performance_score', '$new_position', '$reason', '$file_path', NOW())";

if ($conn->query($sql) === TRUE) {
    // Return success response
    echo json_encode(["status" => "success"]);
} else {
    // Return error response
    echo json_encode(["status" => "error", "message" => $conn->error]);
}

$conn->close();
?>
