<?php
// Database connection settings
$host = 'localhost';
$db   = 'hr_system';   // Change to your actual DB name
$user = 'root';        // Change to your DB username
$pass = '';        // Change to your DB password

// Create connection
$conn = new mysqli($host, $user, $pass, $db);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Check if all required POST fields are received
if (
  isset($_POST['employee_name']) && isset($_POST['leave_type']) &&
  isset($_POST['start_date']) && isset($_POST['end_date']) &&
  isset($_POST['reason']) && isset($_POST['status']) &&
  isset($_POST['date_submitted'])
) {
  // Sanitize input
  $employee_name = $conn->real_escape_string($_POST['employee_name']);
  $leave_type = $conn->real_escape_string($_POST['leave_type']);
  $start_date = $conn->real_escape_string($_POST['start_date']);
  $end_date = $conn->real_escape_string($_POST['end_date']);
  $reason = $conn->real_escape_string($_POST['reason']);
  $status = $conn->real_escape_string($_POST['status']);
  $date_submitted = $conn->real_escape_string($_POST['date_submitted']);

  // Prepare SQL statement
  $stmt = $conn->prepare("INSERT INTO leave_applications (employee_name, leave_type, start_date, end_date, reason, status, date_submitted) VALUES (?, ?, ?, ?, ?, ?, ?)");
  $stmt->bind_param("sssssss", $employee_name, $leave_type, $start_date, $end_date, $reason, $status, $date_submitted);

  // Execute and respond
  if ($stmt->execute()) {
    echo 'success';
  } else {
    echo 'error';
  }

  $stmt->close();
} else {
  echo 'error';
}

$conn->close();
?>
